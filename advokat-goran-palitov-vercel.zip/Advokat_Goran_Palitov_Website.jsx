import React from "react";

export default function AdvokatGoranPalitov() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-500 flex items-center justify-center text-white font-semibold text-lg">GP</div>
            <div>
              <h1 className="text-2xl font-semibold">Адвокатска канцеларија Горан Палитов</h1>
              <p className="text-sm text-gray-500">Бул. Партизански Одреди 37/1, Мезанин лок.18, Скопје</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 items-center text-sm">
            <a href="#services" className="hover:text-indigo-600">Услуги</a>
            <a href="#about" className="hover:text-indigo-600">За адвокатот</a>
            <a href="#contact" className="hover:text-indigo-600">Контакт</a>
            <a href="#team" className="hover:text-indigo-600">Тим</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Hero */}
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold leading-tight">Професионално правно застапување и консултации</h2>
            <p className="mt-4 text-gray-600">Адвокат Горан Палитов обезбедува застапување пред судовите и други органи, правни консултации во области како деловно и стопанско право, работни односи, даночно право, индустриска сопственост и право на човековите права.</p>

            <div className="mt-6 flex gap-4">
              <a href="#contact" className="inline-block bg-indigo-600 text-white px-5 py-3 rounded-lg shadow hover:bg-indigo-700">Закажи консултација</a>
              <a href="#services" className="inline-block border border-indigo-600 text-indigo-600 px-5 py-3 rounded-lg">Преглед на услуги</a>
            </div>

            <div className="mt-6 text-sm text-gray-500">
              <p>Телефон: <a href="tel:+38971237747" className="text-indigo-600">+389 71 237 747</a></p>
              <p>Е-пошта: <a href="mailto:palitov@yahoo.com" className="text-indigo-600">palitov@yahoo.com</a></p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-semibold text-lg">Бесплатна кратка проценка</h3>
            <p className="text-sm text-gray-600 mt-2">Пополнете ги податоците и нашиот тим ќе ве контактира за да ја договориме првата средба.</p>
            <form className="mt-4 grid gap-3">
              <input className="border rounded-md px-3 py-2" placeholder="Име и презиме" />
              <input className="border rounded-md px-3 py-2" placeholder="Е-пошта" />
              <input className="border rounded-md px-3 py-2" placeholder="Телефон" />
              <textarea className="border rounded-md px-3 py-2" rows={4} placeholder="Краток опис на случајот"></textarea>
              <div className="flex gap-2">
                <button type="button" className="flex-1 bg-indigo-600 text-white px-4 py-2 rounded-md">Испрати</button>
                <button type="button" className="flex-1 border border-gray-300 px-4 py-2 rounded-md">Исчисти</button>
              </div>
            </form>
            <p className="text-xs text-gray-400 mt-3">Напомена: Формуларот е пример — интеграцијата со backend за испраќање е опционална.</p>
          </div>
        </section>

        {/* Services */}
        <section id="services" className="mt-16">
          <h3 className="text-2xl font-semibold">Услуги</h3>
          <p className="mt-2 text-gray-600">Широк опсег на правни услуги за физички и правни лица.</p>

          <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {title: 'Застапување пред судови', desc: 'Граѓански, кривични и управни постапки; претставување пред државни органи.'},
              {title: 'Деловно и стопанско право', desc: 'Консултации за корпорации, договорно право, правна ревизија.'},
              {title: 'Работни односи', desc: 'Советување и застапување по прашања од работно-правни односи.'},
              {title: 'Даночно право', desc: 'Советување при даночни прашања и спорови.'},
              {title: 'Индустриска сопственост', desc: 'Заштита на права од индустриска сопственост и патенти.'},
              {title: 'Простор за други специјалности', desc: 'Осигурување, правна помош, заштита на човековите права (Европски суд за човекови права).'}
            ].map((s) => (
              <div key={s.title} className="bg-white p-5 rounded-xl shadow-sm">
                <h4 className="font-semibold">{s.title}</h4>
                <p className="mt-2 text-sm text-gray-600">{s.desc}</p>
                <a href="#contact" className="mt-3 inline-block text-sm text-indigo-600">За повеќе</a>
              </div>
            ))}
          </div>
        </section>

        {/* About */}
        <section id="about" className="mt-16 bg-gradient-to-r from-white to-gray-50 p-6 rounded-xl">
          <h3 className="text-2xl font-semibold">За Горан Палитов</h3>
          <p className="mt-3 text-gray-700">Адвокат Горан Палитов е регистриран како самостоен правник од 2000 година. Неговата канцеларија обезбедува долгогодишно искуство во застапување пред судовите и давање правни консултации во различни правни области.</p>

          <ul className="mt-4 grid sm:grid-cols-2 gap-2 text-sm text-gray-600">
            <li><strong>Адреса:</strong> Бул. Партизански Одреди 37/1, Мезанин лок.18, Скопје</li>
            <li><strong>Телефон:</strong> +389 71 237 747</li>
            <li><strong>Е-пошта:</strong> palitov@yahoo.com</li>
            <li><strong>Регистриран:</strong> 01.04.2000</li>
            <li><strong>Оценка бонитет:</strong> AAA</li>
          </ul>
        </section>

        {/* Team */}
        <section id="team" className="mt-16">
          <h3 className="text-2xl font-semibold">Тимот</h3>
          <p className="mt-2 text-gray-600">Канцеларијата работи со вмрежени адвокати и соработници според потребите на случајот.</p>

          <div className="mt-6 grid sm:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-lg shadow-sm flex gap-4 items-center">
              <div className="w-14 h-14 rounded-full bg-indigo-100 flex items-center justify-center font-semibold">GP</div>
              <div>
                <div className="font-semibold">Горан Палитов</div>
                <div className="text-sm text-gray-500">Адвокат - Основач</div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm flex gap-4 items-center">
              <div className="w-14 h-14 rounded-full bg-indigo-100 flex items-center justify-center font-semibold">AS</div>
              <div>
                <div className="font-semibold">Адвокат/Соработник</div>
                <div className="text-sm text-gray-500">За посложени предмети и специјализирани области</div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="mt-16 bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-2xl font-semibold">Контакт</h3>
          <p className="mt-2 text-gray-600">Посетете ја канцеларијата или контактирајте по телефон/е-пошта.</p>

          <div className="mt-6 grid md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm"><strong>Адреса:</strong> Бул. Партизански Одреди 37/1, Мезанин лок.18, Скопје</p>
              <p className="text-sm mt-1"><strong>Телефон:</strong> <a href="tel:+38971237747" className="text-indigo-600">+389 71 237 747</a></p>
              <p className="text-sm mt-1"><strong>Е-пошта:</strong> <a href="mailto:palitov@yahoo.com" className="text-indigo-600">palitov@yahoo.com</a></p>

              <div className="mt-6">
                <a className="inline-block bg-gray-100 border border-gray-200 px-4 py-2 rounded-md text-sm" href="#">Преземи vCard</a>
              </div>
            </div>

            <div>
              <div className="w-full h-60 bg-gray-100 rounded-md flex items-center justify-center text-gray-400">Map placeholder (вградете Google Maps iframe тука)</div>
            </div>
          </div>
        </section>

        <footer className="mt-16 py-8 text-center text-sm text-gray-500">© {new Date().getFullYear()} Адвокат Горан Палитов — Сите права задржани</footer>
      </main>

      {/* JSON-LD структурирани податоци за SEO */}
      <script type="application/ld+json">
        {`
        {
          "@context": "https://schema.org",
          "@type": "LegalService",
          "name": "Адвокат Горан Палитов",
          "url": "#",
          "telephone": "+38971237747",
          "email": "palitov@yahoo.com",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Бул. Партизански Одреди 37/1, Мезанин лок.18",
            "addressLocality": "Скопје",
            "addressCountry": "MK"
          }
        }
        `}
      </script>
    </div>
  );
}
